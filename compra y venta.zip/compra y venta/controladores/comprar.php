<?php
$valor= $_POST ["valor"];
$producto =$_POST ["producto"];

if($valor> 0)
if($valor<=100000)
{
echo "<br>valor gastado: ", $valor;
echo "<br>descripcion del producto: ", $producto;
}else
{
echo " ojo valor invalido";
}
?>