<?php
$cantidad = $_POST ["cantidad"];
$gastado = $cantidad * 2500;

if($cantidad > 0)
{
echo "<br>cantidad: ", $cantidad ;
echo "<br>valor gastado: ", $gastado;
}else
{
echo " ojo valor invalido";
}
?>