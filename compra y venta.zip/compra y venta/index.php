<script>
  window.onload = function(){
    window.location.href="public/vender.php"
  }
</script>