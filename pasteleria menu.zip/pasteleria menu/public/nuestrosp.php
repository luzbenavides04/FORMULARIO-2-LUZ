<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="../assets/js/color-modes.js"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.122.0">
    <title>Navbar Template · Bootstrap v5.3</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/navbars/">

    

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">

<link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
  body {
      background-color: #f9f3e7; /* Color de fondo suave */
      font-family: 'Comic Sans MS', cursive; /* Tipografía amigable */
  }

  .navbar {
      background-color: #ffcccb; /* Color de la barra de navegación */
  }

  .btn-bd-primary {
      background-color: #ff9f80; /* Botón en tonos pastel */
      border-color: #ff9f80;
  }

  .btn-bd-primary:hover {
      background-color: #ff7f7f; /* Color al pasar el mouse */
      border-color: #ff7f7f;
  }

  .bg-body-tertiary {
      background-color: #fff3e6; /* Color de fondo del contenido */
      border-radius: 10px; /* Bordes redondeados */
      padding: 20px;
  }
</style>

<!-- Custom styles for this template -->
<link href="navbars.css" rel="stylesheet">
</head>
<body>
  <div class="dropdown position-fixed bottom-0 end-0 mb-3 me-3 bd-mode-toggle">
      <button class="btn btn-bd-primary py-2 dropdown-toggle d-flex align-items-center"
              id="bd-theme"
              type="button"
              aria-expanded="false"
              data-bs-toggle="dropdown"
              aria-label="Toggle theme (auto)">
          <span class="visually-hidden" id="bd-theme-text">Toggle theme</span>
      </button>
      <ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="bd-theme-text">
          <li>
              <button type="button" class="dropdown-item d-flex align-items-center" data-bs-theme-value="light" aria-pressed="false">
                  Light
              </button>
          </li>
          <li>
              <button type="button" class="dropdown-item d-flex align-items-center" data-bs-theme-value="dark" aria-pressed="false">
                  Dark
              </button>
          </li>
          <li>
              <button type="button" class="dropdown-item d-flex align-items-center active" data-bs-theme-value="auto" aria-pressed="true">
                  Auto
              </button>
          </li>
      </ul>
  </div>

<main>
  <nav class="navbar navbar-expand navbar-dark bg-dark" aria-label="Second navbar example">
      <div class="container-fluid">
          <a class="navbar-brand" href="#">Pastelería Deliciosa</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample02" aria-controls="navbarsExample02" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarsExample02">
              <ul class="navbar-nav me-auto">
              <li class="nav-item">
                      <a class="nav-link active" aria-current="page" href="inicio.php">Inicio</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="nuestrosp.php">Nuestros Pasteles</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="contacto.php">Contacto</a>
                  </li>
              </ul>
              <form role="search">
                  <input class="form-control" type="search" placeholder="Buscar pasteles" aria-label="Search">
              </form>
          </div>
      </div>
  </nav>

  <div>
      <div class="bg-body-tertiary rounded">
          <div class="col-sm-8 mx-auto">
              <h1>¡Bienvenidos a nuestra Pastelería!</h1>
              <p>Descubre nuestros deliciosos pasteles y dulces hechos con amor y los mejores ingredientes. Desde tartas hasta cupcakes, tenemos algo para todos.</p>
              <p>
                  <a class="btn btn-bd-primary" href="../components/navbar/" role="button">Ver nuestros productos &raquo;</a>
              </p>
          </div>
      </div>
  </div>
</main>
<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
</body>
<h2>Bienvenidos</h2>
   <label for="text">Nombres:</label>
   <input type="text" id="text" name="text" placeholder="digite su nombre"><br><br>

   <label for="text">Apellidos:</label>
   <input type="text" id="text" name="text" placeholder="digite su apelido"><br><br>

   <label>Sexo:</label>
   <input type="radio" id="radio1" name="radio" value="1">
   <label for="radio1">Femenino</label>
   <input type="radio" id="radio2" name="radio" value="2">
   <label for="radio2">Masculino</label><br><br>

   <label for="email">Correo:</label>
   <input type="email" id="email" name="email"><br><br>

   <label for="password">Contraseña:</label>
   <input type="password" id="password" name="password"><br><br>

   <label for="number">Número de T.I-C.C:</label>
   <input type="number" id="number" name="number"><br><br>

   <p>Documento de identidad</p>
   <label for="file"></label>
   <input type="file" id="file" name="file"><br><br>

   <label for="tel">Teléfono:</label>
   <input type="tel" id="tel" name="tel"><br><br>

   <label for="date">Fecha:</label>
   <input type="date" id="date" name="date"><br><br>

   <label for="time">Hora:</label>
   <input type="time" id="time" name="time"><br><br>

   <label for="color">Color favorito:</label>
   <input type="color" id="color" name="color"><br><br>


   <p> ¿Cómo calificarías tu nivel de satisfacción con nuestro servicio?</p>
   <p>Eligue un numero del 1-10</p>
   <label for="range"><label>
   <input type="range" id="range" name="range" min="1" max="10"><br><br>

   <input type="submit" value="Enviar">
   <input type="reset" value="reintentarlo">

</html>
